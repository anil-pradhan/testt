package com.test;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashSet;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/TableSelected")
public class TableSelected extends HttpServlet {
	private static final String LOB_ID = "LOB_ID";
	private static final String LOB_DESC = "LOB_DESC";
	private static final String SUB_LOB_ID = "SUB_LOB_ID";
	private static final String SUB_LOB_DESC = "SUB_LOB_DESC";
	private static final String SUB_LOB_TIER = "SUB_LOB_TIER";
	private static final String _ID = "_ID";
	private static final String _DESC = "_DESC";

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		String table = request.getParameter("table");
		if (table != null && !table.trim().isEmpty()) {
			table = table.trim();
			ArrayList<TableData> data = getTableData(table);
			request.setAttribute("data", data);
			request.getRequestDispatcher("DisplyTableData.jsp").forward(request, response);
		}
	}

	public ArrayList<TableData> getTableData(String tableName) {
		// assumes that following columns are always there
//		  `LOB_ID` varchar(100) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL,
//		  `LOB_DESC` varchar(150) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL,
//		  `SUB_LOB_ID` varchar(100) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL,
//		  `SUB_LOB_DESC` varchar(150) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL,

		ArrayList<String> columns = new ArrayList<String>();
		columns.add(LOB_ID);
		columns.add(LOB_DESC);
		columns.add(SUB_LOB_ID);
		columns.add(SUB_LOB_DESC);
		
		ArrayList<TableData> datas = new ArrayList<TableData>();
		try (Connection connection = ConnectionManager.getConnection()) {
			ResultSet query = connection.prepareStatement("desc " + tableName).executeQuery();
			ArrayList<String> fields = new ArrayList<String>();
			while (query.next()) {
				String column = query.getString("FIELD").toUpperCase();
				if (column.matches(SUB_LOB_TIER + "\\d_(ID|DESC)")) {
					fields.add(column);
				}
			}
			Collections.sort(fields, new Comparator<String>() {
				@Override
				public int compare(String o1, String o2) {
					String substring = o1.substring(SUB_LOB_TIER.length(), o1.lastIndexOf("_"));
					String substring2 = o2.substring(SUB_LOB_TIER.length(), o2.lastIndexOf("_"));
					return Integer.compare(Integer.valueOf(substring), Integer.valueOf(substring2));
				}
			});
			boolean hasTiers = !fields.isEmpty();
			int maxTier = 2;
			if (hasTiers) {
				columns.addAll(fields);
				String string = fields.get(fields.size() - 1);
				maxTier = maxTier + Integer.parseInt(string.substring(SUB_LOB_TIER.length(), string.lastIndexOf("_")));
			}
			ArrayList<TableData> data = new ArrayList<TableData>();
			getDataForNextLevel(connection, tableName, 0, columns, data);
			return data;
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return null;
	}

	private ArrayList<TableData> getDataForNextLevel(Connection connection, String tableName, int currentTier,
			List<String> columns, ArrayList<TableData> finalData) throws SQLException {
		ArrayList<TableData> data = new ArrayList<TableData>();
		String id = columns.get(currentTier);
		String desc = columns.get(currentTier + 1);
		String selectDistinct = selectDistinct(tableName, id, desc);
		ResultSet rs = connection.prepareStatement(selectDistinct).executeQuery();
		while (rs.next()) {
			TableData tableData = new TableData(id, desc, rs.getString(id), rs.getString(desc), currentTier);
			data.add(tableData);
		}
		rs.close();
		for (TableData tableData : data) {
			getDataForNextLevel(connection, tableName, currentTier + 1, columns, tableData, finalData);
		}
		return data;
	}

	private void getDataForNextLevel(Connection connection, String tableName, int currentTier, List<String> columns,
			TableData parentData, ArrayList<TableData> finalData) throws SQLException {
		if (currentTier == columns.size() / 2) {
			finalData.add(parentData);
			return;
		}
		ArrayList<TableData> data = new ArrayList<TableData>();
		String id = columns.get(currentTier * 2);
		String desc = columns.get(currentTier * 2 + 1);
		String selectDistinct = selectDistinct(tableName, id, desc, parentData);
		ResultSet rs = connection.prepareStatement(selectDistinct).executeQuery();
		while (rs.next()) {
			TableData tableData = new TableData(id, desc, rs.getString(id), rs.getString(desc), currentTier);
			data.add(tableData);
			parentData.addChild(tableData);
		}
		rs.close();
		for (TableData tableData : data) {
			getDataForNextLevel(connection, tableName, currentTier + 1, columns, tableData, finalData);
		}
		return;
	}

	public String selectDistinct(String table, String column1, String column2) {
		return "select distinct " + column1 + " , " + column2 + " from " + table;
	}

	public String selectDistinct(String table, String column1, String column2, TableData parent) {
		String q = "select distinct " + column1 + " , " + column2 + " from " + table;
		String s = "";
		while (parent != null) {
			if (!s.equals("")) {
				s = s + " and ";
			}
			s = s + " ( " + parent.getIdColumn() + " = '" + parent.getId() + "' and " + parent.getDescColumn() + " = '"
					+ parent.getDesc() + "')";
			parent = parent.getParent();
		}
		return q + " where " + s;
	}

	public static void main(String[] args) {
		ArrayList<TableData> data = new TableSelected().getTableData("RFO_AGG_BOOKING_DAILY1");
		for (TableData tableData : data) {
			System.out.println(tableData);
			for (TableData tableData2 : tableData.getChildren()) {
				System.out.println("\t" + tableData2);
				for (TableData tableData3 : tableData2.getChildren()) {
					System.out.println("\t\t" + tableData3);
					for (TableData tableData4 : tableData3.getChildren()) {
						System.out.println("\t\t\t" + tableData4);
						for (TableData tableData5 : tableData4.getChildren()) {
							System.out.println("\t\t\t\t" + tableData5);
						}
					}
				}
			}
		}
//		System.out.println("SUB_LOB_TIER2_DESC".matches());
	}

}
