package com.test;

import java.util.ArrayList;
import java.util.List;

public class TableData {
	private String idColumn;
	private String descColumn;
	private String id;
	private String desc;

	private int level;

	private TableData parent;
	private List<TableData> children = new ArrayList<TableData>();

	public TableData(String idColumn, String descColumn, String id, String desc, int level) {
		this.idColumn = idColumn;
		this.descColumn = descColumn;
		this.id = id;
		this.desc = desc;
		this.level = level;
	}

	public void addChild(TableData tableData) {
		children.add(tableData);
		tableData.setParent(this);
	}

	public void setParent(TableData parent) {
		this.parent = parent;
	}

	public String getIdColumn() {
		return idColumn;
	}

	public String getDescColumn() {
		return descColumn;
	}

	public String getId() {
		return id;
	}

	public String getDesc() {
		return desc;
	}

	public String getTree() {
		TableData parent = this.parent;
		StringBuilder sb = new StringBuilder();
		while(parent!=null) {
			if(sb.length()>0) {
				sb.insert(0,"/");
			}
			sb.insert(0,parent.getDesc());
			parent = parent.getParent();
		}
		return sb.toString();
	}
	
	public String getDataTree() {
		TableData parent = this.parent;
		StringBuilder sb = new StringBuilder();
		sb.insert(0, this.idColumn);
		sb.insert(0, this.idColumn);
		while(parent!=null) {
			if(sb.length()>0) {
				sb.insert(0, "/");
			}
			sb.insert(0, parent.getDesc());
			parent = parent.getParent();
		}
		return sb.toString();
	}

	public TableData getParent() {
		return parent;
	}

	public List<TableData> getChildren() {
		return children;
	}

	public int getLevel() {
		return level;
	}
	
	@Override
	public String toString() {
		return "idColumn=" + idColumn + ", descColumn=" + descColumn + ", id=" + id + ", desc=" + desc + ", parent="
				+ parent;
	}

}
