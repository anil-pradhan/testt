package com.test;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class ConnectionManager {
	
	private static final String connectionUrl = "jdbc:mysql://localhost:3306/TEST";
	private static final String driver = "com.mysql.cj.jdbc.Driver";
	private static final String dbuser = "root";
	private static final String dbpassword = "R%&Adpd>}Cx:{iY}x<F_";

	static {
		try {
			Class.forName(driver);
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		}
	}

	public static Connection getConnection() throws SQLException {
		return DriverManager.getConnection(connectionUrl, dbuser, dbpassword);
	}
	
	public static void main(String[] args) throws SQLException {
		System.out.println(getConnection());
	}
}
